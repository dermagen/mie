Необязательная папка для личных лицензионных файлов шрифтов Microsoft.
Поддерживаются имена cambria.ttc (или cambria.ttf), cambriai.ttf, cambriab.ttf,
cambriaz.ttf, calibri.ttf, calibrii.ttf, calibrib.ttf, calibriz.ttf.
Сами файлы не входят в комплект. См. подробности в ../../README.md.
